This is our sidebar content
