<?php
/*
Template Name: Home
*/
get_header(); ?>

<div class="page-wrapper">
  <div class="home-content">
    Homepage Template Loaded<br />
    <?php the_title(); ?>
  </div>
  <div class="clear"></div>
</div>

<?php
get_footer(); ?>
