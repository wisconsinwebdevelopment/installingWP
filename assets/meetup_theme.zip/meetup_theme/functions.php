<?php
  function meetup_css_and_js() {
    wp_enqueue_style('stylesheet', get_stylesheet_directory_uri() . '/style.css', 'style');
  }
  add_action('wp_enqueue_scripts', 'meetup_css_and_js', 99);
?>
