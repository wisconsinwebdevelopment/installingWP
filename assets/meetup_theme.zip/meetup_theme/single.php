<?php
get_header(); ?>

<div class="post-wrapper">
  <div class="content">
    <div class="title"><?php the_title(); ?></div>
    <div class="post-content">
      <?php the_content(); ?>
    </div>
  </div>
  <div class="sidebar">
    <?php get_sidebar(); ?>
  </div>
  <div class="clear"></div>
</div>

<?php
get_footer(); ?>
