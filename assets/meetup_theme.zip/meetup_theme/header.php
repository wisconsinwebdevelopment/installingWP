<html>
<head>
    <meta charset="utf-8">
    <title><?php the_title(); ?></title>
    <?php wp_head(); ?>
</head>
<body>
    <?php wp_nav_menu(); ?>
